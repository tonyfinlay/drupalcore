IMCE plupload
http://drupal.org/project/
====================================


DESCRIPTION
-----------
Integrates plupload with the IMCE file upload to allow multi-file upload


REQUIREMENTS
----------
1. IMCE module
2. plupload integration module


INSTALLING
----------
1. Download and enable the module.
Read more about installing modules at http://drupal.org/node/70151


CONFIGURING AND USING
---------------------
The module automatically replaces the default file upload with the plupload form
