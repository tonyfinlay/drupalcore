casper.test.comment('My first test file');
casper.test.assert(true, "true is so true");
casper.test.done(); // I must be called!
