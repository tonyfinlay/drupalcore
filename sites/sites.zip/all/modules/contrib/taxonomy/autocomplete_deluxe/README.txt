
Enhanced autocomplete widget for drupal 7.x